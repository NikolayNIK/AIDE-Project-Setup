local item = findByID("package");
local package = item.getText();
local packagePath = replace(package, {{".", "/"}});

item = findByID("name");
local name = item.getText();

item = findByID("class");
local class = item.getText();

local replacings = {}
replacings[1] = {"$package$", package};
replacings[2] = {"$name$", name};
replacings[3] = {"$class$", class};

-- /Core
transfer("@/Core/.project", "#/" .. name .. " - Core/.project", replacings);

-- /Core/libs
transferBinary("@/LibGDX/gdx.jar", "#/" .. name .. " - Core/libs/gdx.jar");

-- /Core/src
transfer("@/Core/src/Game.java", "#/" .. name .. " - Core/src/" .. packagePath .. "/core/" .. class .. ".java", replacings);

-- /Android
transfer("@/Android/.project", "#/" .. name .. " - Android/.project", replacings);
transfer("@/Android/AndroidManifest.xml", "#/" .. name .. " - Android/AndroidManifest.xml", replacings);

-- /Android/libs
transferBinary("@/LibGDX/gdx-backend-android.jar", "#/" .. name .. " - Android/libs/gdx-backend-android.jar");
transferBinary("@/LibGDX/arm64-v8a/libgdx.so", "#/" .. name .. " - Android/libs/arm64-v8a/libgdx.so");
transferBinary("@/LibGDX/armeabi/libgdx.so", "#/" .. name .. " - Android/libs/armeabi/libgdx.so");
transferBinary("@/LibGDX/armeabi-v7a/libgdx.so", "#/" .. name .. " - Android/libs/armeabi-v7a/libgdx.so");
transferBinary("@/LibGDX/x86/libgdx.so", "#/" .. name .. " - Android/libs/x86/libgdx.so");
transferBinary("@/LibGDX/x86_64/libgdx.so", "#/" .. name .. " - Android/libs/x86_64/libgdx.so");

-- /Android/res/values
transfer("@/Android/res/values/strings.xml", "#/" .. name .. " - Android/res/values/strings.xml", replacings);
transfer("@/Android/res/values/styles.xml", "#/" .. name .. " - Android/res/values/styles.xml");

-- /Android/res/values-v21
transfer("@/Android/res/values-v21/styles.xml", "#/" .. name .. " - Android/res/values-v21/styles.xml");

-- /Android/src
transfer("@/Android/src/LauncherActivity.java", "#/" .. name .. " - Android/src/" .. packagePath .. "/android/LauncherActivity.java", replacings);

local coreClasspath = "";
local androidClasspath = "";

local checked = findByID("extensions").getChecked();
if checked[1] then
	coreClasspath = coreClasspath .. "	<classpathentry kind=\"lib\" exported=\"true\" path=\"libs/gdx-box2d.jar\"/>\n";
	transferBinary("@/LibGDX/extensions/gdx-box2d/gdx-box2d.jar", "#/" .. name .. " - Core/libs/gdx-box2d.jar");
	transferBinary("@/LibGDX/extensions/gdx-box2d/arm64-v8a/libgdx-box2d.so", "#/" .. name .. " - Android/libs/arm64-v8a/libgdx-box2d.so");
	transferBinary("@/LibGDX/extensions/gdx-box2d/armeabi/libgdx-box2d.so", "#/" .. name .. " - Android/libs/armeabi/libgdx-box2d.so");
	transferBinary("@/LibGDX/extensions/gdx-box2d/armeabi-v7a/libgdx-box2d.so", "#/" .. name .. " - Android/libs/armeabi-v7a/libgdx-box2d.so");
	transferBinary("@/LibGDX/extensions/gdx-box2d/x86/libgdx-box2d.so", "#/" .. name .. " - Android/libs/x86/libgdx-box2d.so");
	transferBinary("@/LibGDX/extensions/gdx-box2d/x86_64/libgdx-box2d.so", "#/" .. name .. " - Android/libs/x86_64/libgdx-box2d.so");
end

if checked[2] then
	coreClasspath = coreClasspath .. "	<classpathentry kind=\"lib\" exported=\"true\" path=\"libs/gdx-bullet.jar\"/>\n";
	transferBinary("@/LibGDX/extensions/gdx-bullet/gdx-bullet.jar", "#/" .. name .. " - Core/libs/gdx-bullet.jar");
	transferBinary("@/LibGDX/extensions/gdx-bullet/arm64-v8a/libgdx-bullet.so", "#/" .. name .. " - Android/libs/arm64-v8a/libgdx-bullet.so");
	transferBinary("@/LibGDX/extensions/gdx-bullet/armeabi/libgdx-bullet.so", "#/" .. name .. " - Android/libs/armeabi/libgdx-bullet.so");
	transferBinary("@/LibGDX/extensions/gdx-bullet/armeabi-v7a/libgdx-bullet.so", "#/" .. name .. " - Android/libs/armeabi-v7a/libgdx-bullet.so");
	transferBinary("@/LibGDX/extensions/gdx-bullet/x86/libgdx-bullet.so", "#/" .. name .. " - Android/libs/x86/libgdx-bullet.so");
	transferBinary("@/LibGDX/extensions/gdx-bullet/x86_64/libgdx-bullet.so", "#/" .. name .. " - Android/libs/x86_64/libgdx-bullet.so");
end

if checked[3] then
	coreClasspath = coreClasspath .. "	<classpathentry kind=\"lib\" exported=\"true\" path=\"libs/gdx-controllers.jar\"/>\n";
	transferBinary("@/LibGDX/extensions/gdx-controllers/gdx-controllers.jar", "#/" .. name .. " - Core/libs/gdx-controllers.jar");
	androidClasspath = androidClasspath .. "	<classpathentry kind=\"lib\" exported=\"true\" path=\"libs/gdx-controllers-android.jar\"/>\n";
	transferBinary("@/LibGDX/extensions/gdx-controllers/gdx-controllers-android.jar", "#/" .. name .. " - Android/libs/gdx-controllers-android.jar");
end

if checked[4] then
	coreClasspath = coreClasspath .. "	<classpathentry kind=\"lib\" exported=\"true\" path=\"libs/gdx-freetype.jar\"/>\n";
	transferBinary("@/LibGDX/extensions/gdx-freetype/gdx-freetype.jar", "#/" .. name .. " - Core/libs/gdx-freetype.jar");
	transferBinary("@/LibGDX/extensions/gdx-freetype/arm64-v8a/libgdx-freetype.so", "#/" .. name .. " - Android/libs/arm64-v8a/libgdx-freetype.so");
	transferBinary("@/LibGDX/extensions/gdx-freetype/armeabi/libgdx-freetype.so", "#/" .. name .. " - Android/libs/armeabi/libgdx-freetype.so");
	transferBinary("@/LibGDX/extensions/gdx-freetype/armeabi-v7a/libgdx-freetype.so", "#/" .. name .. " - Android/libs/armeabi-v7a/libgdx-freetype.so");
	transferBinary("@/LibGDX/extensions/gdx-freetype/x86/libgdx-freetype.so", "#/" .. name .. " - Android/libs/x86/libgdx-freetype.so");
	transferBinary("@/LibGDX/extensions/gdx-freetype/x86_64/libgdx-freetype.so", "#/" .. name .. " - Android/libs/x86_64/libgdx-freetype.so");
end

if checked[5] then
	coreClasspath = coreClasspath .. "	<classpathentry kind=\"lib\" exported=\"true\" path=\"libs/gdx-jnigen.jar\"/>\n";
	transferBinary("@/LibGDX/extensions/gdx-jnigen/gdx-jnigen.jar", "#/" .. name .. " - Core/libs/gdx-jnigen.jar");
end

if checked[6] then
	coreClasspath = coreClasspath .. "	<classpathentry kind=\"lib\" exported=\"true\" path=\"libs/gdx-tools.jar\"/>\n";
	transferBinary("@/LibGDX/extensions/gdx-tools/gdx-tools.jar", "#/" .. name .. " - Core/libs/gdx-tools.jar");
end

-- Core/.classpath
replacings[4] = {"$extensions$", coreClasspath};
transfer("@/Core/.classpath",  "#/" .. name .. " - Core/.classpath", replacings);

-- Android/.classpath
replacings[4] = {"$extensions$", androidClasspath};
transfer("@/Android/.classpath",  "#/" .. name .. " - Android/.classpath", replacings);

return "Looks like done. Go check it out!";