enableFab();

local item = newText("target", "Target:");
item.setText("Android 7.1.2 (API 25)");

local item = newText("minimum", "Minimum:");
item.setText("Android 4.0.3 (API 15)");

item = newDestination("destination", "Destination:");
item.setHint("Path to your project");

item = newEditText("name", "Name:");
item.setHint("Title for you app");

item = newEditText("package", "Package:");
item.setHint("Package of your app");

splitCard();

item = newCheck("activity_enable", "Activity:");

item = newEditText("activity_name", "Name:");
item.setText("MainActivity");