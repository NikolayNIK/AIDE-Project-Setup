package $package$;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class $activity$ extends AppCompatActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}
}
