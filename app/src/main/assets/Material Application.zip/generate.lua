local item = findByID("package");
local package = item.getText();

item = findByID("name");
local name = item.getText();

item = findByID("activity_enable");
local activityEnabled = item.isChecked();

item = findByID("activity_name");
local activityName = item.getText();

local replacings = {{"$package$", package}, {"$name$", name}, {"$activity$", activityName}};

-- /
transferBinary("@/.gitignore", "#/.gitignore");
transfer("@/build.gradle", "#/build.gradle");
transfer("@/settings.gradle", "#/settings.gradle");

-- /app/
transferBinary("@/app/.gitignore", "#/app/.gitignore");
transfer("@/app/build.gradle", "#/app/build.gradle", replacings);
transferBinary("@/app/proguard-rules.pro", "#/app/proguard-rules.pro");

-- /app/src/main/
if activityEnabled then
	transfer("@/app/src/main/AndroidManifest-activity.xml", "#/app/src/main/AndroidManifest.xml", replacings);
else
	transfer("@/app/src/main/AndroidManifest.xml", "#/app/src/main/AndroidManifest.xml", replacings);
end

-- /app/src/main/java/
if activityEnabled then
	transfer("@/app/src/main/java/MainActivity.java", "#/app/src/main/java/" .. replace(package, {{".", "/"}}) .. "/" .. activityName .. ".java", replacings);
end

-- /app/src/main/res/layout/
if activityEnabled then
	transfer("@/app/src/main/res/layout/activity_main.xml", "#/app/src/main/res/layout/activity_main.xml");
end

-- /app/src/main/res/values/
transfer("@/app/src/main/res/values/colors.xml", "#/app/src/main/res/values/colors.xml");
transfer("@/app/src/main/res/values/strings.xml", "#/app/src/main/res/values/strings.xml", replacings);
transfer("@/app/src/main/res/values/styles.xml", "#/app/src/main/res/values/styles.xml");

return "Looks like done! Go check it out!";