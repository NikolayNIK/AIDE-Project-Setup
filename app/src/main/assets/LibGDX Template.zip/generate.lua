local item = findByID("package");
local package = item.getText();
local packagePath = replace(package, {{".", "/"}});

item = findByID("class");
local class = item.getText();

local replacings = {}
replacings[1] = {"$package$", package};
replacings[2] = {"$class$", class};

-- /src/core
transfer("@/src/core/Context.java", "#/src/" .. packagePath .. "/core/Context.java", replacings);
transfer("@/src/core/Game.java", "#/src/" .. packagePath .. "/core/" .. class .. ".java", replacings);
transfer("@/src/core/IContext.java", "#/src/" .. packagePath .. "/core/IContext.java", replacings);
transfer("@/src/core/Screen.java", "#/src/" .. packagePath .. "/core/Screen.java", replacings);
transfer("@/src/core/StageScreen.java", "#/src/" .. packagePath .. "/core/StageScreen.java", replacings);

-- /src/screens
transfer("@/src/screens/LoadingScreen.java", "#/src/" .. packagePath .. "/screens/LoadingScreen.java", replacings);

return "Looks like done. Go check it out!";