enableFab();
setEmptyRecomended(false);

local item = newText("target", "Target:");
item.setText("Android 7.1.2 (API 25)");

item = newText("minimum", "Minimum:");
item.setText("Android 4.0.3 (API 15)");

item = newText("libgdx", "LibGDX:");
item.setText("Any");

item = newDestination("destination", "Core Destination:");
item.setHint("Path to a core project");

item = newEditText("package", "Package:");
item.setHint("Game package");

item = newEditText("class", "Class:");
item.setHint("Main game class");
