package $package$.core;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.Scaling;
import com.badlogic.gdx.utils.viewport.ScalingViewport;

public abstract class StageScreen extends Screen {
	
	private final Stage stage;
	
	public StageScreen() {
		this($class$.getInstance());
	}
	
	public StageScreen(IContext context) {
		super(context);
		this.stage = new Stage(new ScalingViewport(Scaling.stretch, Gdx.graphics.getWidth(), Gdx.graphics.getHeight(), getCamera()), getBatch());
	}
	
	public Stage getStage() {
		return stage;
	}

	@Override
	public void resize(int width, int height) {
		getCamera().viewportWidth = width;
		getCamera().viewportHeight = height;
	}

	@Override
	public void render(float delta) {
		float width = getCamera().viewportWidth = Gdx.graphics.getWidth();
		float height = getCamera().viewportHeight = Gdx.graphics.getHeight();
		getCamera().position.set(width / 2, height / 2, 0);
		
		// TODO Enable if stage will go out of the screen
		//getCamera().update();
		//getBatch().setProjectionMatrix(getCamera().combined);
		stage.act(delta);
		stage.draw();
	}

	@Override
	public void dispose() {
		stage.dispose();
	}

	@Override
	public boolean keyDown(int keyCode) {
		return stage.keyDown(keyCode);
	}

	@Override
	public boolean keyUp(int keyCode) {
		return stage.keyUp(keyCode);
	}

	@Override
	public boolean keyTyped(char key) {
		return stage.keyTyped(key);
	}

	@Override
	public boolean touchDown(int screenX, int screenY, int pointer, int button) {
		return stage.touchDown(screenX, screenY, pointer, button);
	}

	@Override
	public boolean touchUp(int screenX, int screenY, int pointer, int button) {
		return stage.touchUp(screenX, screenY, pointer, button);
	}

	@Override
	public boolean touchDragged(int screenX, int screenY, int pointer) {
		return stage.touchDragged(screenX, screenY, pointer);
	}

	@Override
	public boolean mouseMoved(int screenX, int screenY) {
		return stage.mouseMoved(screenX, screenY);
	}

	@Override
	public boolean scrolled(int amount) {
		return stage.scrolled(amount);
	}
}
