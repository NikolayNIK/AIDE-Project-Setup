package $package$.core;

import com.badlogic.gdx.Preferences;
import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Context implements IContext {

	private final IContext context;
	
	public Context() {
		this($class$.getInstance());
	}
	
	public Context(IContext context) {
		this.context = context;
	}
	
	@Override
	public $class$ getGame() {
		return context.getGame();
	}

	@Override
	public AssetManager getAssets() {
		return context.getAssets();
	}

	@Override
	public Preferences getPreferences() {
		return context.getPreferences();
	}

	@Override
	public SpriteBatch getBatch() {
		return context.getBatch();
	}

	@Override
	public OrthographicCamera getCamera() {
		return context.getCamera();
	}
	
	public IContext getParentContext() {
		return context;
	}
}
