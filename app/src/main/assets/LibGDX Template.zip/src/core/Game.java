package $package$.core;

import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.Preferences;
import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import $package$.screens.LoadingScreen;

public class $class$ implements IContext, ApplicationListener, InputProcessor {
	
	public static final String DEFAULT_PREFERENCES = "settings";
	
	private static $class$ instance;
	
	private Preferences preferences;
	private AssetManager assets;
	private SpriteBatch batch;
	private OrthographicCamera camera;
	private Screen screenLoading;
	private Screen screen, screenSuspended;
	
	public $class$() {
		instance = this;
	}
	
	public static $class$ getInstance() {
		if(instance == null) throw new RuntimeException();
		return instance;
	}

	@Override
	public $class$ getGame() {
		return this;
	}

	@Override
	public AssetManager getAssets() {
		return assets;
	}

	@Override
	public Preferences getPreferences() {
		return preferences;
	}

	@Override
	public SpriteBatch getBatch() {
		return batch;
	}

	@Override
	public OrthographicCamera getCamera() {
		return camera;
	}
	
	public void setScreen(Screen screen) {
		if(this.screen != null) this.screen.hide();
		if(screen != null) {
			screen.show();
			screen.resize(Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
		}
		
		this.screen = screen;
	}
	
	@Override
	public void create() {
		batch = new SpriteBatch();
		camera = new OrthographicCamera();
		preferences = Gdx.app.getPreferences(DEFAULT_PREFERENCES);
		Texture.setAssetManager(assets = new AssetManager());
		
		// TODO Load up assets
		
		setScreen(screenLoading = new LoadingScreen());
		
		Gdx.input.setInputProcessor(this);
	}

	public void onLoadingFinished() {
		if(screen != null) screen.hide();
		if(screenSuspended == null) {
			// TODO Show starting screen
		} else {
			setScreen(null);
			screenSuspended.resume();
			screenSuspended.resize(Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
			screen = screenSuspended;
		}
	}
	
	@Override
	public void resize(int width, int height) {
		if(screen != null) screen.resize(width, height);
	}

	@Override
	public void render() {
		if(screen != null) screen.render(Gdx.graphics.getDeltaTime());
	}

	@Override
	public void pause() {
		if(screen != null) {
			screen.pause();
			if(screen != screenLoading) screenSuspended = screen;
		}
		
		screen = null;
	}

	@Override
	public void resume() {
		setScreen(screenLoading);
	}

	@Override
	public void dispose() {
		if(screen != null) screen.hide();
		
		screenLoading.dispose();
		batch.dispose();
		assets.dispose();
	}

	@Override
	public boolean keyDown(int keyCode) {
		return screen == null ? false : screen.keyDown(keyCode);
	}

	@Override
	public boolean keyUp(int keyCode) {
		return screen == null ? false : screen.keyUp(keyCode);
	}

	@Override
	public boolean keyTyped(char key) {
		return screen == null ? false : screen.keyTyped(key);
	}

	@Override
	public boolean touchDown(int screenX, int screenY, int pointer, int button) {
		return screen == null ? false : screen.touchDown(screenX, screenY, pointer, button);
	}

	@Override
	public boolean touchUp(int screenX, int screenY, int pointer, int button) {
		return screen == null ? false : screen.touchUp(screenX, screenY, pointer, button);
	}

	@Override
	public boolean touchDragged(int screenX, int screenY, int pointer) {
		return screen == null ? false : screen.touchDragged(screenX, screenY, pointer);
	}

	@Override
	public boolean mouseMoved(int screenX, int screenY) {
		return screen == null ? false : screen.mouseMoved(screenX, screenY);
	}

	@Override
	public boolean scrolled(int amount) {
		return screen == null ? false : screen.scrolled(amount);
	}
}
