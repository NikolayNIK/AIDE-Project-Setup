package $package$.core;

import com.badlogic.gdx.Preferences;
import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public interface IContext {

	public $class$ getGame();
	public AssetManager getAssets();
	public Preferences getPreferences();
	public SpriteBatch getBatch();
	public OrthographicCamera getCamera();
}
