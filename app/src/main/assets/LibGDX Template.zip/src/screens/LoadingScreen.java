package $package$.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import $package$.core.Screen;

public class LoadingScreen extends Screen {

	@Override
	public void render(float delta) {
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		Gdx.gl.glClearColor(1, 1, 1, 1);
		if(getAssets().update()) {
			getGame().onLoadingFinished();
		}
	}
}
