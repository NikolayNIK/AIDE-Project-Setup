enableFab();

local item = newText("target", "Target:");
item.setText("Android 7.1.2 (API 25)");

item = newText("minimum", "Minimum:");
item.setText("Android 4.0.3 (API 15)");

item = newText("libgdx", "LibGDX:");
local scanner = scan("@/LibGDX/VERSION");
item.setText(scanner.nextLine());
scanner.close();

item = newDestination("destination", "Destination:");
item.setHint("Path to a project");

item = newEditText("name", "Name:");
item.setHint("Game title");

item = newEditText("package", "Package:");
item.setHint("Game package");

item = newEditText("class", "Class:");
item.setHint("Main game class");

splitCard();

item = newMultiChoose("extensions", "Extensions:");
item.setItems({"Box2D", "Bullet", "Controllers", "Freetype", "JNIGen", "Tools"});