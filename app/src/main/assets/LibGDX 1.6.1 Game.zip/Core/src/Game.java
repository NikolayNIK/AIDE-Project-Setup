package $package$.core;

import com.badlogic.gdx.Game;

public class $class$ extends Game {

	@Override
	public void create() {
		
	}
}
